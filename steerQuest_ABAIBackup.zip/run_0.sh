read var

cd solver
g++ main.cpp Boid.cpp Flocking.cpp Simulation.cpp MapLoader.cpp -std=c++0x -D__LINUX_COMPILE -o ../runtime/flock-solve -lopenvdb -lHalf -ltbb -lpthread -lX11 -ldynamic -I./ -L./
echo built
cd ..
cd runtime
echo in runtime
./run_scene0.sh
if ($var == 1) then
sleep 10
killall scene0
else 
sleep 1
fi

echo lauched

