#include <iostream>
#include <fstream>
#include "Boid.h"
#include "move.h"

float barn_x,barn_y;
float sheep_x =0;
float sheep_y =0;
int speed=1;
float x;
int y =0;
float post[4];
void main() {
move();
/*
ifstream myfile ("Post.txt");
myfile.open();
	while (getline (myline,x && y <=3) {
	post[y} = x;
	y++;

	}
*/
}


int move(){
	if (sheep_x > barn_x)  {
	sheep_x -= speed;
	}
		if (sheep_x < barn_x){
		sheep_x += speed ;
		}
			if (sheep_y > barn_y) {
			sheep_y -= speed;
			}
	if (sheep_y < barn_y) {
	sheep_y += speed;
	}
	new Boid(sheep_x,sheep_y,barn_x,barn_y,1,0.3,1,1,1,1,1,1,1);
/*
	ofstream sheep_move;
	sheep.open ("sheep_move.txt");
	sheep << sheep_x <<endl << sheep_y;
	sheep.close();
*/
return 0;

}
void get_post(float x,float y,float x_1,float y_1) {
	sheep_x = x;
	sheep_y = y;
	barn_x = x_1;
	barn_y = y_1;
}
