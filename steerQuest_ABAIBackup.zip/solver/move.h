void get_post(float x,float y,float x_1,float y_1) {

}
